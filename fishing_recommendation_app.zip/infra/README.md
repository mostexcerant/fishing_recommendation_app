# Infra

Use docker-compose to run the backend locally.
From the infra directory:
  docker-compose up --build
Ensure you have filled out backend/.env with API keys.
