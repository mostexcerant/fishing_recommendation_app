# Fishing Recommendation Frontend

This is a simple React frontend that talks to the backend at /api/* endpoints.
During development you can run the backend on http://localhost:8000 and use a proxy
or configure CORS. For production, serve the built frontend from a CDN or from your backend.
