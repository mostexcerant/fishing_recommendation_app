# Fishing Recommendation Mobile (Expo)

This folder contains a sample Expo/React Native app structure. To bootstrap:
1. Install expo-cli
2. expo init fishing-mobile
3. Replace App.js with the sample below and connect to your backend.
